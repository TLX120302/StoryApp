package com.example.storyapp_muhamadkhoirfahni.view.map

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.example.storyapp_muhamadkhoirfahni.data.pref.userModel
import com.example.storyapp_muhamadkhoirfahni.data.userRepository

class MapsVM (private val repository: userRepository) : ViewModel() {

    fun getStoriesWithLocation(location: Int = 1) = repository.getStoriesWithLocation(location)

    fun getSession(): LiveData<userModel> {
        return repository.getSession().asLiveData()
    }
}