package com.example.storyapp_muhamadkhoirfahni.view.map

import android.content.pm.PackageManager
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.annotation.ColorInt
import androidx.annotation.DrawableRes
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.core.graphics.drawable.DrawableCompat

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.example.storyapp_muhamadkhoirfahni.databinding.ActivityMapsBinding
import com.example.storyapp_muhamadkhoirfahni.R
import com.example.storyapp_muhamadkhoirfahni.data.ResultState
import com.example.storyapp_muhamadkhoirfahni.view.ViewModelFactory
import com.google.android.gms.maps.model.BitmapDescriptor
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.MapStyleOptions

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private val viewModel by viewModels<MapsVM> {
        ViewModelFactory.getInstance(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        getMyLocation()
        setMapStyle()
        getMapStory()


        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.uiSettings.isIndoorLevelPickerEnabled = true
        mMap.uiSettings.isCompassEnabled = true
        mMap.uiSettings.isMapToolbarEnabled = true

        mMap.setOnMapLongClickListener { latLng ->
            mMap.addMarker(
                MarkerOptions()
                    .position(latLng)
                    .title("New Marker")
                    .snippet("Lat: ${latLng.latitude} Long: ${latLng.longitude}")
                    .icon(vectorToBitmap(R.drawable.map, Color.parseColor("#3DDC84")))
            )
        }
        mMap.setOnPoiClickListener { pointOfInterest ->
            val poiMarker = mMap.addMarker(
                MarkerOptions()
                    .position(pointOfInterest.latLng)
                    .title(pointOfInterest.name)
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_MAGENTA))
            )
            poiMarker?.showInfoWindow()
        }
    }

    //   conver vector to bitmap
    private fun vectorToBitmap(@DrawableRes id: Int, @ColorInt color: Int): BitmapDescriptor {
        val vectorDrawable = ResourcesCompat.getDrawable(resources, id, null)
        vectorDrawable ?: run {
            Log.e("BitmapHelper", "Resource not found")
            return BitmapDescriptorFactory.defaultMarker()
        }
        val bitmap = Bitmap.createBitmap(
            vectorDrawable.intrinsicWidth,
            vectorDrawable.intrinsicHeight,
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(bitmap)
        vectorDrawable.setBounds(0, 0, canvas.width, canvas.height)
        DrawableCompat.setTint(vectorDrawable, color)
        vectorDrawable.draw(canvas)
        return BitmapDescriptorFactory.fromBitmap(bitmap)
    }

    //    mendapatkan lokasi sendiri
    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            isGranted.takeIf { it }?.let { getMyLocation() }
        }
    private fun getMyLocation() {
        val permission = android.Manifest.permission.ACCESS_FINE_LOCATION

        (ContextCompat.checkSelfPermission(
            this.applicationContext,
            permission
        ) == PackageManager.PERMISSION_GRANTED)
            .takeIf { it }
            ?.let { mMap.isMyLocationEnabled = true }
            ?: requestPermissionLauncher.launch(permission)
    }
    private fun setMapStyle() {
        try {
            mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.map_style))
                ?.apply { if (!this) Log.e(TAG, "Style parsing failed.") }
        } catch (exception: Resources.NotFoundException) {
            Log.e(TAG, "Can't find style. Error: ", exception)
        }
    }
    private fun getMapStory(){
        viewModel.getStoriesWithLocation().observe(this) { result ->
            when (result) {
                is ResultState.Success -> result.data.listStory.forEach { storyItem ->
                    val latLng = LatLng(storyItem.lat ?: 0.0, storyItem.lon ?: 0.0)
                    mMap.addMarker(
                        MarkerOptions()
                            .position(latLng)
                            .title(storyItem.name)
                            .snippet(storyItem.description)
                    )
                }.also {
                    val lastResult = result.data.listStory.last()
                    val latLng = LatLng(lastResult.lat!!, lastResult.lon!!)
                    mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng))
                }

                is ResultState.Error -> Toast.makeText(this, result.error, Toast.LENGTH_SHORT).show()

                is ResultState.Loading -> {
                }
            }
        }
    }

    //use live template logt to create this
    companion object {
        private const val TAG = "MapsActivity"
    }
}
