package com.example.storyapp_muhamadkhoirfahni.data.Database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.storyapp_muhamadkhoirfahni.data.remote.response.stories.ListStoryItem


@Database(
    entities = [ListStoryItem::class, RemoteKeys::class],
    version = 2,
    exportSchema = false
)
abstract class StoryDB : RoomDatabase() {
    abstract fun storyDao(): DAOstory
    abstract fun remoteKeysDao(): DAOremoteKeys
    companion object {
        @Volatile
        private var INSTANCE: StoryDB? = null

        @JvmStatic
        fun getDatabase(context: Context): StoryDB {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    StoryDB::class.java, "story_database"
                )
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}