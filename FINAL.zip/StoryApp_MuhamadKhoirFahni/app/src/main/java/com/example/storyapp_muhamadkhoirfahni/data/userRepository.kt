package com.example.storyapp_muhamadkhoirfahni.data

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.liveData
import androidx.paging.ExperimentalPagingApi
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import com.example.storyapp_muhamadkhoirfahni.R
import com.example.storyapp_muhamadkhoirfahni.data.Database.StoryDB
import com.example.storyapp_muhamadkhoirfahni.data.Database.StoryRemoteMediator
import com.example.storyapp_muhamadkhoirfahni.data.pref.UserPreference
import com.example.storyapp_muhamadkhoirfahni.data.pref.userModel
import com.example.storyapp_muhamadkhoirfahni.data.remote.api.ApiConfig
import com.example.storyapp_muhamadkhoirfahni.data.remote.api.ApiService
import com.example.storyapp_muhamadkhoirfahni.data.remote.response.login.LoginResponse
import com.example.storyapp_muhamadkhoirfahni.data.remote.response.register.RegisterResponse
import com.example.storyapp_muhamadkhoirfahni.data.remote.response.stories.ListStoryItem
import com.example.storyapp_muhamadkhoirfahni.data.remote.response.stories.PostStoryResponse
import com.example.storyapp_muhamadkhoirfahni.data.remote.response.stories.StoryResponse
import com.example.storyapp_muhamadkhoirfahni.util.reduceFileImage
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.HttpException
import java.io.File

class userRepository private constructor(
    private val userPreference: UserPreference,
    private var apiService:ApiService,
    private val storyDatabase: StoryDB

) {
    fun register(name: String, email: String, password: String): LiveData<ResultState<RegisterResponse>> = liveData {
        emit(ResultState.Loading)
        try {
            val response = apiService.register(name, email, password)
            emit(ResultState.Success(response))
        } catch (e: Exception) {
            emit(ResultState.Error(e.message.toString()))
        }
    }
    fun login(email: String, password: String): LiveData<ResultState<LoginResponse>> = liveData {
        emit(ResultState.Loading)
        try {
            val response = apiService.login(email, password)
            userPreference.saveSession(userModel(email, response.loginResult.token, true))
            emit(ResultState.Success(response))
        } catch (e: Exception) {
            emit(ResultState.Error(e.message.toString()))
        }
    }
    fun getSession(): Flow<userModel> {
        return userPreference.getSession()
    }

    suspend fun logout() {
        userPreference.logout()
    }

    @OptIn(ExperimentalPagingApi::class)
    fun getStory(coroutineScope: CoroutineScope): LiveData<ResultState<PagingData<ListStoryItem>>> =
        liveData {
            emit(ResultState.Loading)
            val token = userPreference.getToken().first()
            apiService = ApiConfig.getApiService(token)
            val response = Pager(
                config = PagingConfig(pageSize = 5),
                remoteMediator = StoryRemoteMediator(storyDatabase, apiService),
                pagingSourceFactory = { storyDatabase.storyDao().getAllStory() }
            )

            response.flow
                .catch { e ->
                    when (e) {
                        is HttpException -> {
                            val response = e.response()?.errorBody()?.string()
                            val error = Gson().fromJson(response, StoryResponse::class.java)
                            emit(ResultState.Error(error.message))
                        }
                        else -> {
                            emit(ResultState.Error(e.message.toString()))
                        }
                    }
                }
                .collect { pagingData ->
                    emit(ResultState.Success(pagingData))
                }
        }

    fun getDetailStory(id: String): LiveData<ResultState<ListStoryItem>> = liveData {
        emit(ResultState.Loading)
        try {

            val response = apiService.detailStory(id)
            val result = response.story
            emit(ResultState.Success(result))
        } catch (e: Exception) {
            emit(ResultState.Error(e.message.toString()))
        }
    }

    fun uploadStory(context: Context, file: File?, description: String,

                    ): LiveData<ResultState<PostStoryResponse>> = liveData {
        emit(ResultState.Loading)
        try {
            val token = runBlocking {
                userPreference.getToken().first()
            }

            apiService = ApiConfig.getApiService(token)
            if (file != null) {
                val files = file.reduceFileImage()
                val desc = description.toRequestBody("text/plain".toMediaType())
                val imageFile = files.asRequestBody("image/jpeg".toMediaType())
                val imageMultipart: MultipartBody.Part = MultipartBody.Part.createFormData(
                    "photo",
                    files.name,
                    imageFile
                )
                val response = apiService.uploadStory(imageMultipart, desc)
                emit(ResultState.Success(response))
            } else {
                emit(ResultState.Error(context.getString(R.string.error)))
            }

        } catch (e: HttpException) {
            val response = e.response()?.errorBody()?.string()
            val error = Gson().fromJson(response, PostStoryResponse::class.java)
            emit(ResultState.Error(error.message))
        } catch (e: Exception) {
            emit(ResultState.Error(e.message.toString()))
        }
    }
    fun getStoriesWithLocation(location: Int = 1): LiveData<ResultState<StoryResponse>> = liveData {
        emit(ResultState.Loading)
        runCatching {
            val token = userPreference.getSession().first().Token
            val api = ApiConfig.getApiService(token)
            val storiesLocResponse = api.getStoriesWithLocation(location)
            if (storiesLocResponse.error == false) {
                emit(ResultState.Success(storiesLocResponse))
            } else {
                emit(ResultState.Error(storiesLocResponse.message ?: "Location Not Found"))
            }
        }.onFailure { e ->
            if (e is HttpException) {
                Log.d("login", e.message.toString())
            }
            emit(ResultState.Error(e.message.toString()))
        }
    }

    companion object {
        @Volatile
        private var instance: userRepository? = null
        fun getInstance(
            userPreference: UserPreference,
            apiService: ApiService,
            database: StoryDB

        ): userRepository =
            instance ?: synchronized(this) {
                instance ?: userRepository(userPreference, apiService,database)
            }.also { instance = it }


    }
}