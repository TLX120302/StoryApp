package com.example.storyapp_muhamadkhoirfahni.view.Detail

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.switchMap
import com.example.storyapp_muhamadkhoirfahni.data.userRepository

class DetailVM (private val userRepository: userRepository): ViewModel() {

    private val storyId = MutableLiveData<String>()

    fun setStoryId(id: String) {
        storyId.value = id
    }
    val detailStory = storyId.switchMap {
        userRepository.getDetailStory(it)
    }
}