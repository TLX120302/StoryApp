package com.example.storyapp_muhamadkhoirfahni.view.main

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import com.example.storyapp_muhamadkhoirfahni.data.ResultState
import com.example.storyapp_muhamadkhoirfahni.data.pref.userModel
import com.example.storyapp_muhamadkhoirfahni.data.remote.response.stories.ListStoryItem
import com.example.storyapp_muhamadkhoirfahni.data.userRepository
import kotlinx.coroutines.launch

class MainViewModel(private val repository: userRepository) : ViewModel() {
    fun getSession(): LiveData<userModel> {
        return repository.getSession().asLiveData()
    }

    fun getStory(): LiveData<ResultState<PagingData<ListStoryItem>>> {
        return repository.getStory(viewModelScope)
    }

    fun logout() {
        viewModelScope.launch {
            repository.logout()
        }
    }

}