package com.example.storyapp_muhamadkhoirfahni.view.upload

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.storyapp_muhamadkhoirfahni.data.ResultState
import com.example.storyapp_muhamadkhoirfahni.data.remote.response.stories.PostStoryResponse
import com.example.storyapp_muhamadkhoirfahni.data.userRepository
import java.io.File

class UploadVM (private val userRepository: userRepository) : ViewModel() {
    fun uploadStory(context: Context, file: File?, description: String, ): LiveData<ResultState<PostStoryResponse>> {
        return userRepository.uploadStory(context, file, description, )
    }
}