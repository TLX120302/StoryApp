package com.example.storyapp_muhamadkhoirfahni.view.login

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.storyapp_muhamadkhoirfahni.data.ResultState
import com.example.storyapp_muhamadkhoirfahni.data.remote.response.login.LoginResponse
import com.example.storyapp_muhamadkhoirfahni.data.userRepository

class LoginViewModel(private val UserRepository: userRepository) : ViewModel() {
    fun saveSession(email: String, password: String): LiveData<ResultState<LoginResponse>> {
        return UserRepository.login(email, password)
    }
}

