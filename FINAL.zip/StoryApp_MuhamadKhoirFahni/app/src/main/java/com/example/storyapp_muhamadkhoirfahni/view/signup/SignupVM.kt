package com.example.storyapp_muhamadkhoirfahni.view.signup

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.storyapp_muhamadkhoirfahni.data.ResultState
import com.example.storyapp_muhamadkhoirfahni.data.remote.response.register.RegisterResponse
import com.example.storyapp_muhamadkhoirfahni.data.userRepository

class SignupVM (private val userRepository: userRepository) : ViewModel(){
    fun register(name: String, email: String, password: String): LiveData<ResultState<RegisterResponse>> {
        return userRepository.register(name, email, password)
    }
}