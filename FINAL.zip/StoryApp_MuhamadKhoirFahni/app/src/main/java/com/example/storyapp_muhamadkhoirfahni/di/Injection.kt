package com.example.storyapp_muhamadkhoirfahni.di

import android.content.Context
import com.example.storyapp_muhamadkhoirfahni.data.Database.StoryDB
import com.example.storyapp_muhamadkhoirfahni.data.userRepository
import com.example.storyapp_muhamadkhoirfahni.data.pref.UserPreference
import com.example.storyapp_muhamadkhoirfahni.data.pref.dataStore
import com.example.storyapp_muhamadkhoirfahni.data.remote.api.ApiConfig
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking


object Injection {
    fun provideRepository(context: Context): userRepository {
        val pref = UserPreference.getInstance(context.dataStore)
        val user = runBlocking { pref.getSession().first() }
        val apiService = ApiConfig.getApiService(user.toString())
        val database = StoryDB.getDatabase(context)
        return userRepository.getInstance(pref,apiService,database)
    }

}