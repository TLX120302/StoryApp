package com.example.storyapp_muhamadkhoirfahni.data.pref

data class userModel(
    val Email: String,
    val Token: String,
    val isLogin: Boolean = false
)
