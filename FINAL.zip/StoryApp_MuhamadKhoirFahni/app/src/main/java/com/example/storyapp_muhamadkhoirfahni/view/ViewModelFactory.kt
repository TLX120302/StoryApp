package com.example.storyapp_muhamadkhoirfahni.view

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.storyapp_muhamadkhoirfahni.data.userRepository
import com.example.storyapp_muhamadkhoirfahni.di.Injection
import com.example.storyapp_muhamadkhoirfahni.view.Detail.DetailVM
import com.example.storyapp_muhamadkhoirfahni.view.login.LoginViewModel
import com.example.storyapp_muhamadkhoirfahni.view.main.MainViewModel
import com.example.storyapp_muhamadkhoirfahni.view.map.MapsVM
import com.example.storyapp_muhamadkhoirfahni.view.signup.SignupVM
import com.example.storyapp_muhamadkhoirfahni.view.upload.UploadVM

class ViewModelFactory(private val repository: userRepository) : ViewModelProvider.NewInstanceFactory() {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(MainViewModel::class.java) -> {
                MainViewModel(repository) as T
            }
            modelClass.isAssignableFrom(LoginViewModel::class.java) -> {
                LoginViewModel(repository) as T
            }
            modelClass.isAssignableFrom(SignupVM::class.java) -> {
                SignupVM(repository) as T
            }
            modelClass.isAssignableFrom(DetailVM::class.java) -> {
                DetailVM(repository) as T
            }
            modelClass.isAssignableFrom(UploadVM::class.java) -> {
                UploadVM(repository) as T
            }
            modelClass.isAssignableFrom(MapsVM::class.java) -> {
                MapsVM(repository) as T
            }
            else -> throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: ViewModelFactory? = null
        @JvmStatic
        fun getInstance(context: Context): ViewModelFactory {
            if (INSTANCE == null) {
                synchronized(ViewModelFactory::class.java) {
                    INSTANCE = ViewModelFactory(Injection.provideRepository(context))
                }
            }
            return INSTANCE as ViewModelFactory
        }
    }
}