package com.example.storyapp_muhamadkhoirfahni

import com.example.storyapp_muhamadkhoirfahni.data.remote.response.stories.ListStoryItem

object DataDummy {

    fun generateDummyListStoryResponse(): List<ListStoryItem> {
        val items: MutableList<ListStoryItem> = arrayListOf()
        for (i in 0..100) {
            val quote = ListStoryItem(
                i.toString(),
                "author + $i",
                "story $i",
                "description $i",
                "id$i",
            )
            items.add(quote)
        }
        return items
    }
}